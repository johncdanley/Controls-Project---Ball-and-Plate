

% Table width and length (m)
L_tbl = 27.5 / 100; 

% Distance between SRV02 output gear shaft and coupled joint (m)
r_arm = 1 * K_IN2M; 

% Gravitational constant (m/s^2)
g = 9.81;   

% Radius of ball (m)
r_b = 39.25 / 2 / 1000;

% Mass of ball (kg)
m_b = 0.003;

% Moment of inertia of ball (kg.m^2)
J_b = 2/5 * m_b * r_b^2;