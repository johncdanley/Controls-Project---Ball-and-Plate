%Initialize API

coppelia=remApi('remoteApi');

% using the prototype file (remoteApiProto.m)

coppelia.simxFinish(-1);

% just in case, close all opened connections

clientID=coppelia.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)       

disp('Connected to remote API server');       


coppelia.simxGetStringSignal(clientID,'distance',coppelia.simx_opmode_streaming);               

set_param('V1', 'SimulationCommand', 'start')               

% rovolute joint handle
    jh = [0 0];
    [r , jh(1) ] = coppelia.simxGetObjectHandle(clientID, 'Motor_1',coppelia.simx_opmode_blocking);
    [r , jh(2) ] = coppelia.simxGetObjectHandle(clientID, 'Motor_2',coppelia.simx_opmode_blocking);
    
    while true
        
        [res,retInts,retFloats,retStrings,retBuffer]=coppelia.simxCallScriptFunction(clientID,'Vision_sensor',coppelia.sim_scripttype_childscript,'CoordCalc',[],[],[],'',coppelia.simx_opmode_blocking);
        xcoord=retFloats(1);
        ycoord=retFloats(2);

         XC=xcoord;
         set_param('V1/Constant_X','Value',num2str(XC));
         pause (0.01);
         
         YC=ycoord;
         set_param('V1/Constant_Y','Value',num2str(YC));
         pause(0.1);
        
        thetaxC= get_param('V1/Thetax_out','RuntimeObject');
        CmotorAnglex=thetaxC.InputPort(1).Data; 
        
        thetayC= get_param('V1/Thetay_out','RuntimeObject');
        CmotorAngley=thetayC.InputPort(1).Data;
        
        
        coppelia.simxSetJointTargetPosition(clientID,jh(1),CmotorAnglex,coppelia.simx_opmode_streaming);
        coppelia.simxSetJointTargetPosition(clientID,jh(2),CmotorAngley,coppelia.simx_opmode_streaming);
    end
    
else
    disp('Connection to API server failed')
    
end





 

