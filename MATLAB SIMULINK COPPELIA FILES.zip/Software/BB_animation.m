[n,m] = size(xout);

for i=1:n
    plot(xout(i),yout(i), '-o')
     axis([-L_tbl/2 L_tbl/2 -L_tbl/2 L_tbl/2])
    pause(.1)
end

comet(xout,yout)